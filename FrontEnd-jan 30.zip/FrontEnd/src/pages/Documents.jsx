function Documents() {
  return (
    <div className="mx-auto max-w-[1400px] px-4 py-6 sm:px-6">
      <div className="text-xl font-semibold text-foreground">Documents</div>
      <div className="mt-2 text-sm text-muted-foreground">
        Placeholder page.
      </div>
    </div>
  );
}

export default Documents;
